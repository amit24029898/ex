<?php
namespace Expia\Customcartpricerule\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
use Magento\Checkout\Helper\Cart;
use Magento\Catalog\Model\Session;

class Purchaseany implements \Magento\Framework\Event\ObserverInterface
{

	/**
     * @var \Magento\Framework\ObjectManagerInterface
     */
    protected $_objectManager;
    protected $_helper;
    protected $catalogSession;

    public function __construct(
        \Magento\Framework\ObjectManagerInterface $objectmanager,
        \Magento\Checkout\Helper\Cart $cartHelper,
        \Magento\Catalog\Model\Session $catalogSession
    
      
    )
    {
        $this->_objectManager = $objectmanager;
        $this->_helper = $cartHelper;
        $this->catalogSession = $catalogSession;
       
    }	
  public function execute(\Magento\Framework\Event\Observer $observer)
  {
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/sales-rule45.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $item=$observer['item'];
       /* $quoteRepository = $this->_objectManager->create('Magento\Quote\Model\QuoteRepository');
        $quote = $quoteRepository->get($item->getQuoteId());*/
        $product = $this->_objectManager->create('Magento\Catalog\Model\Product')->load($item->getProductId());
        $cats = $product->getCategoryIds();
        //$logger->info('50 - '.json_encode($item->getProductId()));
        //$logger->info('60 - '.json_encode($cats));

        $conf_enable = $this->_objectManager->get('Magento\Framework\App\Config\ScopeConfigInterface')->getValue('durmmond_rules/general/enable');

        if($conf_enable == "1"){

           $glove_ids = $this->_objectManager->get('Magento\Framework\App\Config\ScopeConfigInterface')->getValue('durmmond_rules/general/glove_ids');
           if(!empty($glove_ids)){
            //$logger->info('GloveIds - '.json_encode($glove_ids)); 
           }
           $bottoms_ids = $this->_objectManager->get('Magento\Framework\App\Config\ScopeConfigInterface')->getValue('durmmond_rules/general/bottoms_ids'); 
           if(!empty($bottoms_ids)){
            
            //$logger->info('bottomsIds - '.json_encode($bottoms_ids)); 
           }

          //$logger->info('99 - '.json_encode($conf_enable));
        }

      $toal_discountAmount = 0;
      $final_discount_amount = 0;
      $session_value =0;
      $discountAmount1=0;
      $discountAmount = 0;

      /*  $logger->info('60 - '.json_encode($quote->getData()));*/
        if(in_array('141', $cats) || in_array('143', $cats)){
            
            $count = $this->_helper->getSummaryCount();
            $logger->info('total count - '.json_encode($count));
            //$toal_discountAmount = 0;
            
            if($count > 1){
              
              /*$product_id= $item->getProductId();
              $logger->info('product-ID - '.json_encode($product_id));

              $logger->info('item-qty - '.json_encode($item->getItemsQty()));
              $price = $item->getBasePriceInclTax();
              $logger->info('item-price - '.json_encode($price));
              
              $itemid = count($item->getProductId());
              $logger->info('itemid - '.$itemid);
              $discountAmount = ($price*40)/100; 
              $this->catalogSession->setMyValue($discountAmount);  
                       
                 //
                  $final_discount_amount = $session_value + $discountAmount;
                  $session_value = $this->catalogSession->getMyValue();
                  
              
                 $qty = ($item->getQty() -1); 
                 /*if($qty == 0){
                  $qty = 1;
                 }*/
                 
                /* $logger->info('qty - '.json_encode($qty));
                // $toal_discountAmount = $qty * $discountAmount ;  
                 
                // $session_value = $this->catalogSession->getMyValue();
                
                 $logger->info('discountAmount - '.json_encode($discountAmount));
                // $logger->info('totalDiscountAmount - '.json_encode($toal_discountAmount));
                 $logger->info('FinalDiscountAmount - '.json_encode($final_discount_amount));
                 //$item->setDiscountLabel('Purchase any Gloves product and get a 2nd for 40% off');
                 $item->setDiscountAmount($final_discount_amount);
                 $item->setBaseDiscountAmount($final_discount_amount)->save();
                // $session_value = $this->catalogSession->getMyValue();
                 //$logger->info('Session value - '.json_encode($session_value));
                 $logger->info("---------end------------");*/


             $logger->info('item-qty - '.json_encode($item->getItemsQty()));
             $price = $item->getBasePriceInclTax();
             $logger->info('item-price - '.json_encode($price));
             $itemid = count($item->getProductId());
             $logger->info('itemid - '.$itemid);
             $discountAmount1 = ($price*40)/100; 
             $qty = ($item->getQty() -1); 
             $discountAmount1 = $discountAmount1 * $qty;
                 
                 $logger->info('qty - '.json_encode($qty));
                 $discountAmount += $discountAmount1 ;  


                 $logger->info('discountAmount - '.json_encode($discountAmount));
                 $item->setDiscountLabel('Purchase any Gloves product & get a 2nd for 40% off');
                 $item->setDiscountAmount($discountAmount);
                 $item->setBaseDiscountAmount($discountAmount)->save();
                  
          }
        }
  }  
}