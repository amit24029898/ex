<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

// This module is created to add new action of 'Purchase any category & get a 2nd for 40% off ' in admin under cart price rule 'conditions'
// Jira Task No: DG-864
// Author: Purvi
// Date: 16, Jan. 2020

namespace Expia\Customcartpricerule\Plugin\Rule\Metadata;

class ValueProvider {
    public function afterGetMetadataValues(
        \Magento\SalesRule\Model\Rule\Metadata\ValueProvider $subject,
        $result
    ) {
        $applyOptions = [
            'label' => __('Expia'),
            'value' => [
                [
                    'label' => 'Purchase any Glove & get a 2nd for 40% off',
                    'value' => 'purchase-any-glove-get-2-40off',
                ],
               
            ],
        ];
        array_push($result['actions']['children']['simple_action']['arguments']['data']['config']['options'], $applyOptions);
        return $result;
    }
}
